# Snake Game

A simple Snake game that supports **touch controls on Android (Pydroid 3)** and **keyboard controls on PC**.

## How to play

- **On Android:**  
  - Open `main.py` in **Pydroid 3**.  
  - Use swipe/touch to control the snake.

- **On PC:**  
  - Run `main.py` with Python and Pygame installed.  
  - Use **Arrow Keys** to move the snake.

## Files

- `main.py` - The main game code
- `GameOver.ogg` - Game over sound
- `food.ogg` - Eating apple sound
- `assets/` - Additional images (If you want to add)

## Requirements

- Python 3.x
- Pygame

## Notes

- The snake moves on a grid of 15px blocks.
- Head is orange, body is green.
- The score and high score are displayed at the top.