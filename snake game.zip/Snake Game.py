import pygame
import sys
import random

# ----------------------------
# Initialize Pygame and sounds
# ----------------------------
pygame.init()
pygame.mixer.init()
game_over_sound = pygame.mixer.Sound('GameOver.ogg')
food_sound = pygame.mixer.Sound("food.ogg") 

# ----------------------------
# Screen setup
# ----------------------------
width, height = 500, 400
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Snake Game")

# ----------------------------
# Colors
# ----------------------------
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BG = (10, 10, 255)
WHITE = (255, 255, 255)

# ----------------------------
# Snake setup
# ----------------------------
snake_block = 15
speed = snake_block
player_pos = [width // 2, height // 2]
snake_list = []
snake_len = 1

# ----------------------------
# Apple setup
# ----------------------------
colors = [(255, 0, 0), (255, 165, 0), (255, 255, 255)]
apple_x = random.randrange(0, width, snake_block)
apple_y = random.randrange(50, height, snake_block)
apple_color = random.choice(colors)

# ----------------------------
# Clock for controlling FPS
# ----------------------------
clock = pygame.time.Clock()
fps = 15

# ----------------------------
# Touch / direction variables
# ----------------------------
start_x = None
start_y = None
touch_direction_x = 0
touch_direction_y = 0

# ----------------------------
# Keyboard direction variables (for PC)
# ----------------------------
key_direction_x = 0
key_direction_y = 0

# ----------------------------
# Draw the snake
# ----------------------------
def draw_snake(snake_list):
    for i, segment in enumerate(snake_list):
        color = (255, 165, 0) if i == len(snake_list) - 1 else GREEN  # Head is orange
        pygame.draw.rect(screen, color, (segment[0], segment[1], snake_block, snake_block))

# ----------------------------
# Draw the score
# ----------------------------
def draw_score(score, color, high_score):
    font = pygame.font.SysFont('font.tff', 25)
    text = font.render(f"Score: {score} High score: {high_score}", True, color)
    screen.blit(text, (10, 10))
    pygame.draw.line(screen, color, (0, 40), (width, 40), 2)

# ----------------------------
# Display text on screen
# ----------------------------
def window_text(text, color, font='font.tff'):
    font = pygame.font.SysFont(font, 25)
    msg = font.render(text, True, color)
    screen.blit(msg, (width / 4, height / 3))

# ----------------------------
# Game Over screen
# ----------------------------
def Game_over():
    game_over_sound.play()
    alpha = 0
    fade_speed = 15
    start_time = pygame.time.get_ticks()
    run_game = None

    while alpha < 255:
        current_time = pygame.time.get_ticks()
        if current_time - start_time > 5000 / 2:
            run_game = False
            break

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.FINGERDOWN or event.type == pygame.KEYDOWN:
                run_game = True
                break

        s = pygame.Surface((width, height))
        s.set_alpha(alpha)
        s.fill((0,0,0))
        screen.blit(s, (0,0))
        window_text('Game Over! Touch or Press any key to restart', RED)
        pygame.display.update()
        alpha += fade_speed
        clock.tick(30)

    return run_game

# ----------------------------
# Reset the game state
# ----------------------------
def reset_game():
    global player_pos, snake_list, snake_len, apple_x, apple_y, apple_color
    player_pos = [width // 2, height // 2]
    snake_list = []
    snake_len = 1
    apple_x = random.randrange(0, width, snake_block)
    apple_y = random.randrange(50, height, snake_block)
    apple_color = random.choice(colors)
    return 0

# ----------------------------
# Main game loop
# ----------------------------
def game_loop():
    global start_x, start_y, touch_direction_x, touch_direction_y
    global key_direction_x, key_direction_y
    global apple_x, apple_y, snake_list, snake_len, player_pos, apple_color

    high_score = 0
    run = True

    while run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            # Touch controls
            elif event.type == pygame.FINGERDOWN:
                start_x, start_y = event.x, event.y
            elif event.type == pygame.FINGERUP:
                dx = event.x - start_x if start_x is not None else 0
                dy = event.y - start_y if start_y is not None else 0
                if abs(dx) > abs(dy):
                    touch_direction_x = snake_block if dx > 0.02 else -snake_block if dx < -0.02 else 0
                    touch_direction_y = 0
                elif abs(dy) > abs(dx):
                    touch_direction_y = snake_block if dy > 0.02 else -snake_block if dy < -0.02 else 0
                    touch_direction_x = 0
                start_x, start_y = None, None
            # Keyboard controls for PC
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    key_direction_x = -snake_block
                    key_direction_y = 0
                elif event.key == pygame.K_RIGHT:
                    key_direction_x = snake_block
                    key_direction_y = 0
                elif event.key == pygame.K_UP:
                    key_direction_y = -snake_block
                    key_direction_x = 0
                elif event.key == pygame.K_DOWN:
                    key_direction_y = snake_block
                    key_direction_x = 0

        # Update position
        player_pos[0] += key_direction_x if key_direction_x != 0 else touch_direction_x
        player_pos[1] += key_direction_y if key_direction_y != 0 else touch_direction_y

        # Snap to grid
        player_pos[0] = round(player_pos[0] / snake_block) * snake_block
        player_pos[1] = round(player_pos[1] / snake_block) * snake_block

        # Update snake body
        snake_head = [player_pos[0], player_pos[1]]
        body_segments = snake_list[:-1]
        snake_list.append(snake_head)
        if len(snake_list) > snake_len:
            del snake_list[0]

        # Draw everything
        screen.fill(BG)
        draw_snake(snake_list)
        draw_score(snake_len - 1, WHITE, high_score)
        pygame.draw.circle(screen, apple_color, (apple_x, apple_y), snake_block / 1.5)

        # Draw boundaries
        pygame.draw.line(screen, WHITE, (0, 40), (width, 40), 1)
        pygame.draw.line(screen, WHITE, (0, height), (width, height), 1)
        pygame.draw.line(screen, WHITE, (0, 40), (0, height), 1)
        pygame.draw.line(screen, WHITE, (width, 40), (width , height ), 1)

        # Check boundaries
        if player_pos[0] < 0 or player_pos[0] >= width or player_pos[1] < 40 or player_pos[1] >= height:
            result = Game_over()
            if result: reset_game()
            else: break

        # Eating the apple
        if abs(player_pos[0] - apple_x) < snake_block and abs(player_pos[1] - apple_y) < snake_block:
            food_sound.play()
            snake_len += 1
            high_score = max(high_score, snake_len - 1)
            for _ in range(10):
                bubble_x = apple_x + random.randint(-10, 10)
                bubble_y = apple_y + random.randint(-10, 10)
                bubble_radius = random.randint(1, 3)
                pygame.draw.circle(screen, apple_color, (bubble_x, bubble_y), bubble_radius)
                pygame.display.update()
                pygame.time.delay(50)
            apple_x = random.randrange(0, width, snake_block)
            apple_y = random.randrange(50, height, snake_block)
            apple_color = random.choice(colors)

        # Collision with self
        head_rect = pygame.Rect(snake_head[0], snake_head[1], snake_block, snake_block)
        for segment in body_segments:
            segment_rect = pygame.Rect(segment[0], segment[1], snake_block, snake_block)
            if head_rect.colliderect(segment_rect):
                result = Game_over()
                if result:
                    reset_game()
                else:
                    run = False
                break

        # Dynamic FPS based on snake length
        base_fps = 15
        max_fps = 30
        fps = min(base_fps + (snake_len - 1) // 2, max_fps)

        pygame.display.flip()
        clock.tick(fps)

# ----------------------------
# Start the game
# ----------------------------
game_loop()
pygame.quit()
sys.exit()